#!/bin/sh

# Set tap0 non-persistent if already up:
sudo ip link set dev tap0 down > /dev/null 2>&1 || true 
sudo ip link delete tap0 > /dev/null 2>&1 || true

# Load the Xmodmap for Mac US keyboards:
xmodmap ~/xmodmap.macx

# Set tap0 persistent and owned by root:
sudo ip tuntap add dev tap0 mode tap
sudo ip addr add 192.168.6.1/24 dev tap0
sudo ip link set dev tap0 up

cd $HOME/vlm
# Start OG2 VLM in unprivileged mode but with a delay of a few seconds 
# on very fast systems like a new MBP, using the command “sleep n &&”:
# ./genera -network "tap0:INTERNET|192.168.6.2;gateway=192.168.6.1”
sleep 2 && ./genera -network "tap0:INTERNET|192.168.6.2;gateway=192.168.6.1"
